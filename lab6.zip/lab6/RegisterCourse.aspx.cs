﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.SessionState;
using System.Web.UI.WebControls;

namespace lab6
{
    public partial class RegisterCourse : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if it is the first time web page load 
            if (this.IsPostBack == false)
            {
                divCourseSelectList.Visible = true;
                divCourseTable.Visible = false;
                List<Course> availableCourses = Helper.GetAvailableCourses();

                // display available courses and weekly hours
                string checkBoxText;

                for (int i = 0; i < availableCourses.Count; i++)
                {
                    checkBoxText = availableCourses[i].Title + " - " + availableCourses[i].WeeklyHours + "hours/week";
                    //courseList.Items.Add(new ListItem(checkBoxText, availableCourses[i].WeeklyHours.ToString()));
                    courseList.Items.Add(new ListItem(checkBoxText, availableCourses[i].Code));

                }
                // display available courses and weekly hours end
            }
        }

        protected void Submit(object sender, EventArgs e)
        {
            studentNameCopy.Text = studentName.Text;
            int fullTimeMaxHour = 16;
            int partTimeMaxCourse = 3;
            int coopMaxCourse = 2;
            int coopMaxHour = 4;
            int selectedCourseAmount = 0;
            int selectedHours = 0;

            // a bool variable for switching display the available course list and selected course table
            // validation = false  : display the available course list
            // validation = true   : display the selected course table
            bool validation = false;

            // create a new list for storing selected courses
            List<Course> selectedCourseList = new List<Course>();

            // student name text box validate
            if (studentName.Text != "")
            {
                pnlResult.Visible = false;
                divCourseTable.Visible = false;
                
                string selectedCourseType = courseType.SelectedValue;

                // loop the course check box list
                for (int i = 0; i < courseList.Items.Count; i++) 
                {
                    // retrieve the selected items and count the hours & number of selected courses 
                    if (courseList.Items[i].Selected)
                    {
                        Course selectedCourse = Helper.GetCourseByCode(courseList.Items[i].Value);
                        selectedCourseAmount += 1;
                        selectedHours += selectedCourse.WeeklyHours;

                        // store the selected course objects into a list
                        selectedCourseList.Add(selectedCourse);
                    }
                   
                }
                
                // validation based on course type
                if (selectedCourseType == "1")
                {
                    // Full time course type
                    if (selectedHours > 16)
                    {
                        // if not pass the validation, clear the selected course list
                        selectedCourseList.Clear();
                        pnlResult.Visible = true;
                        error.Text = "Your selection exceeds the maximum weekly hours: " + fullTimeMaxHour.ToString();
                    }
                    else
                    {
                        validation = true;
                    }
                }
                else if (selectedCourseType == "2")
                {
                    // Part time course type
                    if (selectedCourseAmount > 3)
                    {
                        selectedCourseList.Clear();
                        pnlResult.Visible = true;
                        error.Text = "Your selection exceeds the maximum number of courses: " + partTimeMaxCourse.ToString();
                    }
                    else
                    {
                        validation = true;
                    }
                }
                else
                {
                    // Co-op course type
                    if (selectedCourseAmount > 2)
                    {
                        selectedCourseList.Clear();
                        pnlResult.Visible = true;
                        error.Text = "Your selection exceeds the maximum number of courses: " + coopMaxCourse.ToString();
                    }
                    else if ( selectedHours > 4)
                    {
                        selectedCourseList.Clear();
                        pnlResult.Visible = true;
                        error.Text = "Your selection exceeds the maximum weekly hours: " + coopMaxHour.ToString();
                    }
                    else
                    {
                        validation = true;
                    }
                }
                // validation based on course type end
            }
            else
            {
                pnlResult.Visible = true;
                error.Text = "You must enter a name!";
            }
            // student name text box validate end

            // display course table after validation successful
            if (validation == true)
            {
                divCourseSelectList.Visible = false;
                divCourseTable.Visible = true;

                // disabled the radio select and input box
                courseType.Enabled = false;
                studentName.Enabled = false;
                
                // create table header
                TableHeaderRow headerRow = new TableHeaderRow();
                courseTable.Controls.Add(headerRow);
                Label header1 = new Label();
                Label header2 = new Label();
                Label header3 = new Label();
                
                for(int i = 0; i < 3; i++)
                {
                    TableHeaderCell headerCell = new TableHeaderCell();
                    if (i == 0)
                    {
                        header1.Text = "Course Code";
                        headerCell.Controls.Add(header1);
                    }
                    else if (i == 1)
                    {
                        header2.Text = "Course Title";
                        headerCell.Controls.Add(header2);
                    }
                    else
                    {
                        header3.Text = "Weekly Hours";
                        headerCell.Controls.Add(header3);
                    }
                    headerRow.Controls.Add(headerCell);
                }
                // create table header end

                //create table rows
                for (int i = 0; i < selectedCourseList.Count; i++)
                {
                    TableRow row = new TableRow();
                    courseTable.Controls.Add(row);

                    Label courseCode = new Label();
                    Label courseTitle = new Label();
                    Label courseHour = new Label();
                   
                    // create table cells
                    for (int j = 0; j < 3; j++)
                    {
                        TableCell cell = new TableCell();
                        courseCode.Text = selectedCourseList[i].Code;
                        courseTitle.Text = selectedCourseList[i].Title;
                        courseHour.Text = selectedCourseList[i].WeeklyHours.ToString();

                        if (j == 0)
                        {
                            cell.Controls.Add(courseCode);
                        }
                        else if (j == 1)
                        {
                            cell.Controls.Add(courseTitle);
                        }
                        else
                        {
                            cell.Controls.Add(courseHour);
                        }

                        row.Controls.Add(cell);
                    }
                    // create table cells end              
                }
                // create table rows end

                // create bottom row display the total number of courses
                TableRow bmRow = new TableRow();
                courseTable.Controls.Add(bmRow);
                Label totalCourseRow = new Label();
                
                //TableCell bmCell = new TableCell();
                //bmCell.Controls.Add(totalCourseRow);
                //bmRow.Controls.Add(bmCell);

                for (int i = 0; i < 3; i++)
                {
                    TableCell bmCell = new TableCell();
                    if (i == 0)
                    {
                        totalCourseRow.Text = "";
                        bmCell.Controls.Add(totalCourseRow);
                    }
                    else if (i == 1)
                    {
                        totalCourseRow.Text = null;
                        bmCell.Controls.Add(totalCourseRow);
                    }
                    else
                    {
                        totalCourseRow.Text = "Total: " + selectedHours.ToString();
                        bmCell.Controls.Add(totalCourseRow);
                    }
                    bmRow.Controls.Add(bmCell);
                }
                // create bottom row display the total number of courses end
            }
            // table validation end
        }
    }
}
